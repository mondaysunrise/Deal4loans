function addBankdetails1()
{
		var ni = document.getElementById('myDiv1');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails1();" style="display:block; cursor:pointer; width:188px;">American Express</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input type="checkbox" value="american hpcl" name="american" style="border:none"/> HPCL Credit Card<br><input type="checkbox" value="american shopper" name="american" style="border:none"/> Shoppers Stop Silver<br> Credit<br></div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails1()
{
		var ni = document.getElementById('myDiv1');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	
	
	
	function addBankdetails2()
{
		var ni = document.getElementById('myDiv2');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails2();" style="display:block; cursor:pointer; width:188px;">Axis Bank</span><div id="bgimg_pnl" style="width:180px; text-align:left;"><input type="checkbox" value="axis gold" name="axis" style="border:none"/> Gold Credit Card<br></div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails2()
{
		var ni = document.getElementById('myDiv2');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	
	
	
	
		function addBankdetails3()
{
		var ni = document.getElementById('myDiv3');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails3();" style="display:block; cursor:pointer; width:188px;">Barclays</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input type="checkbox" value="barclays smart" name="barclays" style="border:none"/> Smart Budget Credit<br>Card<br><input type="checkbox" value="barclays yatra" name="barclays" style="border:none"/> Yatra Barclays Platinum<br>Card<br><input type="checkbox" value="barclays premier" name="barlays" style="border:none"/> Premier League Credit<br>Card<br><input type="checkbox" value="barclays times" name="barclays" style="border:none"/> Times Card from<br>Barclays and TimesofMoney<br></div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails3()
{
		var ni = document.getElementById('myDiv3');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	
	
	
		function addBankdetails4()
{
		var ni = document.getElementById('myDiv4');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails4();" style="display:block; cursor:pointer; width:188px;">Citibank</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input type="checkbox" value="citibank oil" name="citibank" style="border:none"/> Indian Oil Credit Card<br><input name="citibank" type="checkbox" id="citibank" style="border:none" value="citibank gold"/> Jet Airways Gold Credit<br>Card<br><input name="citibank" type="checkbox" id="citibank" style="border:none" value="citibank platinum"/>   Jet Airways Platinum<br>Credit Card<br><input name="citibank" type="checkbox" id="citibank" style="border:none" value="citibank silver"/>  Shoppers Stop Silver<br>Credit Card<br></div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails4()
{
		var ni = document.getElementById('myDiv4');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	
		function addBankdetails5()
{
		var ni = document.getElementById('myDiv5');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails5();" style="display:block; cursor:pointer; width:188px;">HDFC Bank</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="hdfc" type="checkbox" id="hdfc" style="border:none" value="hdfc silver"/> Silver Credit Card<br><input name="hdfc" type="checkbox" id="hdfc" style="border:none" value="hdfc gold"/> Gold Credit Card<br><input name="hdfc" type="checkbox" id="hdfc" style="border:none" value="hdfc titanium"/> Titanium Credit Card<br><input name="hdfc" type="checkbox" id="hdfc"  style="border:none" value="hdfc platinum"/> Platinum Credit Card<br><input name="hdfc" type="checkbox" id="hdfc"  style="border:none" value="hdfc visa"/> Visa Signature Credit<br>Card</div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails5()
{
		var ni = document.getElementById('myDiv5');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	
	
		function addBankdetails6()
{
		var ni = document.getElementById('myDiv6');
			if(ni.innerHTML=="")
		{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails6();" style="display:block; cursor:pointer; width:188px;">HSBC</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="hsbc" type="checkbox" id="hsbc" style="border:none" value="hsbc platinum"/> Platinum Credit Card<br><input name="hsbc" type="checkbox" id="hsbc" style="border:none" value="hsbc gold"/> Gold Credit Card<br><input name="hsbc" type="checkbox" id="hsbc"  style="border:none" value="hsbc classic"/> Classic Credit Card</div><div id="btm_pnl"></div></div>';
		}
	return true;
	}


function removeBankdetails6()
{
		var ni = document.getElementById('myDiv6');
		
		
		if(ni.innerHTML!="")
		{
		ni.innerHTML = '';
		}
		return true;

	}
	


function addBankdetails6()
{
var ni = document.getElementById('myDiv6');
if(ni.innerHTML=="")
{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails6();" style="display:block; cursor:pointer; width:188px;">HSBC</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="hsbc" type="checkbox" id="hsbc" style="border:none" value="hsbc platinum"/> Platinum Credit Card<br><input name="hsbc" type="checkbox" id="hsbc" style="border:none" value="hsbc gold"/> Gold Credit Card<br><input name="hsbc" type="checkbox" id="hsbc"  style="border:none" value="hsbc classic"/> Classic Credit Card</div><div id="btm_pnl"></div></div>';
}
return true;
}

function removeBankdetails6()
{
var ni = document.getElementById('myDiv6');
if(ni.innerHTML!="")
{
ni.innerHTML = '';
}
return true;
}	




function addBankdetails7()
{
var ni = document.getElementById('myDiv7');
if(ni.innerHTML=="")
{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails7();" style="display:block; cursor:pointer; width:188px;">ICICI Bank</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="icici" type="checkbox" id="icici" style="border:none" value="icici hpcl"/> HPCL Credit Card<br><input name="icici" type="checkbox" id="icici" style="border:none" value="icici bazaar"/> Big Bazaar Credit Card<br> <input name="icici" type="checkbox" id="icici"  style="border:none" value="icici titanium"/> Titanium Credit Card<br> <input name="icici" type="checkbox" id="icici"  style="border:none" value="icici platinum"/> Platinum Credit Card<br><input name="icici" type="checkbox" id="icici"  style="border:none" value="icici signature"/> Signature Credit Card</div><div id="btm_pnl"></div></div>';
}
return true;
}

function removeBankdetails7()
{
var ni = document.getElementById('myDiv7');
if(ni.innerHTML!="")
{
ni.innerHTML = '';
}
return true;
}



function addBankdetails8()
{
var ni = document.getElementById('myDiv8');
if(ni.innerHTML=="")
{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails8();" style="display:block; cursor:pointer; width:188px;">Standard Chartered</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="icici" type="checkbox" id="standard" style="border:none" value="standard sahara"/> Air Sahara Credit Card</div><div id="btm_pnl"></div></div>';
}
return true;
}

function removeBankdetails8()
{
var ni = document.getElementById('myDiv8');
if(ni.innerHTML!="")
{
ni.innerHTML = '';
}
return true;
}



function addBankdetails9()
{
var ni = document.getElementById('myDiv9');
if(ni.innerHTML=="")
{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails9();" style="display:block; cursor:pointer; width:188px;">Kotak Bank</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="kotak" type="checkbox" id="kotak" style="border:none" value="kotak fortune"/> Fortune Gold Card<br><input name="kotak" type="checkbox" id="kotak" style="border:none" value="kotak trump"/> Trump Gold Card<br> <input name="kotak" type="checkbox" id="kotak"  style="border:none" value="kotak league"/> League Platinum Card <br> <input name="kotak" type="checkbox" id="kotak"  style="border:none" value="kotak royale"/> Royale Signature Card</div><div id="btm_pnl"></div></div>';
}
return true;
}

function removeBankdetails9()
{
var ni = document.getElementById('myDiv9');
if(ni.innerHTML!="")
{
ni.innerHTML = '';
}
return true;
}


function addBankdetails10()
{
var ni = document.getElementById('myDiv10');
if(ni.innerHTML=="")
{
					ni.innerHTML = '<div id="tp_pnl"><span onClick="removeBankdetails10();" style="display:block; cursor:pointer; width:188px;">SBI</span><div id="bgimg_pnl" style=" width:180px; text-align:left;"><input name="kotak" type="checkbox" id="kotak" style="border:none" value="kotak fortune"/> Fortune Gold Card<br><input name="kotak" type="checkbox" id="kotak" style="border:none" value="kotak trump"/> Trump Gold Card<br> <input name="kotak" type="checkbox" id="kotak"  style="border:none" value="kotak league"/> League Platinum Card <br> <input name="kotak" type="checkbox" id="kotak"  style="border:none" value="kotak royale"/> Royale Signature Card</div><div id="btm_pnl"></div></div>';
}
return true;
}

function removeBankdetails10()
{
var ni = document.getElementById('myDiv10');
if(ni.innerHTML!="")
{
ni.innerHTML = '';
}
return true;
}
	
	

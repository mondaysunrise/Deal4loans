<?php
//include 'scripts/functions.php';

	session_start();
	

	//$msg = "Sorry, Please Login First!!!!";
	if(!isset($_SESSION['Email'])){
	//$url = 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/General_Request.php';
	//echo "<script language=javascript>alert('".$msg."');"." location.href='$url'"."</script>";
	//$Msg = getAlert("Please Login First!!!!!!!", True, $url);
	//echo $Msg;
//header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/Request_Loan_Personal_New.php");
	//exit;
	}

	//$url = "http://localhost:8080/public/deal4loans/";
	//echo "<script language=javascript>alert('Please enter a valid username.')</script>";
	//ob_start();
	//header("Location: http://".$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF'])."/");
	

?>